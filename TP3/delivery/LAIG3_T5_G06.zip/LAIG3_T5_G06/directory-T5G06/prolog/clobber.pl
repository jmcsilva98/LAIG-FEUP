:- consult('input.pl').
:- consult('display.pl').
:- consult('logic.pl').
:- consult('bot.pl').
:- consult('menu.pl').
:- use_module(library(system)).
:- use_module(library(random)).
:- use_module(library(lists)).


clobber:-   main_menu.
