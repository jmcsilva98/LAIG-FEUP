
function Move(cell,newCell,lastBoard,player){
  this.cell=cell;
  this.newCell=newCell;
  this.lastBoard=lastBoard;
  this.player=player;
}