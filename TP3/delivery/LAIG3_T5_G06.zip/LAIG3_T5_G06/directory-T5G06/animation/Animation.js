/**
 * Animation
 * @param gl {WebGLRenderingContext}
 * @constructor
 */

class Animation {
  constructor(scene, animationId, animationTime) {

  this.scene=scene;
  this.animationId = animationId;
  this.animationTime = animationTime;



  }




};
